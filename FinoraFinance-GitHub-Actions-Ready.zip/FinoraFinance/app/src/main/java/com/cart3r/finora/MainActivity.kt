package com.cart3r.finora

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.room.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

@Entity(tableName = "transactions", indices = [Index("date")])
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val amount: Double,
    val type: String,
    val category: String,
    val note: String = "",
    val account: String = "Cash",
    val date: Long = System.currentTimeMillis()
)

@Entity(tableName = "budgets")
data class BudgetEntity(@PrimaryKey val category: String, val amount: Double)

@Dao
interface FinanceDao {
    @Query("SELECT * FROM transactions ORDER BY date DESC") fun transactions(): Flow<List<TransactionEntity>>
    @Insert suspend fun insert(tx: TransactionEntity)
    @Delete suspend fun delete(tx: TransactionEntity)
    @Query("DELETE FROM transactions") suspend fun clearTransactions()
    @Query("SELECT * FROM budgets") fun budgets(): Flow<List<BudgetEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveBudget(b: BudgetEntity)
}

@Database(entities = [TransactionEntity::class, BudgetEntity::class], version = 1, exportSchema = false)
abstract class FinanceDb : RoomDatabase() {
    abstract fun dao(): FinanceDao
    companion object {
        @Volatile private var instance: FinanceDb? = null
        fun get(context: android.content.Context): FinanceDb = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(context.applicationContext, FinanceDb::class.java, "finora.db").build().also { instance = it }
        }
    }
}

class FinanceVm(private val dao: FinanceDao) : ViewModel() {
    val transactions = dao.transactions()
    val budgets = dao.budgets()
    fun add(amount: Double, type: String, category: String, note: String, account: String) = viewModelScope.launch {
        dao.insert(TransactionEntity(amount = amount, type = type, category = category, note = note, account = account))
    }
    fun delete(tx: TransactionEntity) = viewModelScope.launch { dao.delete(tx) }
    fun saveBudget(category: String, amount: Double) = viewModelScope.launch { dao.saveBudget(BudgetEntity(category, amount)) }
}

@Composable
fun financeVm(): FinanceVm {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    return viewModel(factory = object : androidx.lifecycle.ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T = FinanceVm(FinanceDb.get(ctx).dao()) as T
    })
}

private val Bg = Color(0xFF08090C)
private val Panel = Color(0xFF13161C)
private val Red = Color(0xFFE53935)
private val Green = Color(0xFF36C98F)
private val TextMuted = Color(0xFF9AA1AD)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { Finora() } }
}

private fun tr(lang: String, key: String): String = mapOf(
    "English" to mapOf("home" to "Dashboard", "tx" to "Transactions", "add" to "Add", "analytics" to "Analytics", "settings" to "Settings", "balance" to "Current balance", "income" to "Income", "expense" to "Expenses", "recent" to "Recent transactions", "amount" to "Amount", "category" to "Category", "note" to "Note", "account" to "Account", "save" to "Save transaction", "food" to "Food", "transport" to "Transport", "bills" to "Bills", "shopping" to "Shopping", "health" to "Health", "other" to "Other", "cash" to "Cash", "bank" to "Bank", "card" to "Card", "monthly" to "Spending by category", "budget" to "Budgets", "language" to "Language", "empty" to "No transactions yet", "all" to "All"),
    "Français" to mapOf("home" to "Tableau de bord", "tx" to "Transactions", "add" to "Ajouter", "analytics" to "Analyses", "settings" to "Réglages", "balance" to "Solde actuel", "income" to "Revenus", "expense" to "Dépenses", "recent" to "Transactions récentes", "amount" to "Montant", "category" to "Catégorie", "note" to "Note", "account" to "Compte", "save" to "Enregistrer", "food" to "Alimentation", "transport" to "Transport", "bills" to "Factures", "shopping" to "Achats", "health" to "Santé", "other" to "Autre", "cash" to "Espèces", "bank" to "Banque", "card" to "Carte", "monthly" to "Dépenses par catégorie", "budget" to "Budgets", "language" to "Langue", "empty" to "Aucune transaction", "all" to "Toutes"),
    "العربية" to mapOf("home" to "الرئيسية", "tx" to "المعاملات", "add" to "إضافة", "analytics" to "التحليلات", "settings" to "الإعدادات", "balance" to "الرصيد الحالي", "income" to "الدخل", "expense" to "المصاريف", "recent" to "آخر المعاملات", "amount" to "المبلغ", "category" to "الفئة", "note" to "ملاحظة", "account" to "الحساب", "save" to "حفظ المعاملة", "food" to "الطعام", "transport" to "النقل", "bills" to "الفواتير", "shopping" to "التسوق", "health" to "الصحة", "other" to "أخرى", "cash" to "نقدي", "bank" to "البنك", "card" to "البطاقة", "monthly" to "المصاريف حسب الفئة", "budget" to "الميزانيات", "language" to "اللغة", "empty" to "لا توجد معاملات بعد", "all" to "الكل")
)[lang]?.get(key) ?: key

private fun money(v: Double): String = NumberFormat.getNumberInstance(Locale.US).format(v) + " DZD"
private fun categoryLabel(lang: String, key: String) = tr(lang, key)
private val categories = listOf("food", "transport", "bills", "shopping", "health", "other")
private val accounts = listOf("cash", "bank", "card")

@Composable
fun Finora() {
    var lang by remember { mutableStateOf("English") }
    var page by remember { mutableIntStateOf(0) }
    val vm = financeVm()
    val txs by vm.transactions.collectAsState(initial = emptyList())
    val budgets by vm.budgets.collectAsState(initial = emptyList())
    MaterialTheme(colorScheme = darkColorScheme(primary = Red, background = Bg, surface = Panel)) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            Column(Modifier.fillMaxSize()) {
                Header(lang) { lang = it }
                Box(Modifier.weight(1f)) {
                    when (page) {
                        0 -> Dashboard(txs, lang)
                        1 -> Transactions(txs, lang, vm)
                        2 -> AddTransaction(lang, vm)
                        3 -> Analytics(txs, budgets, lang, vm)
                        else -> Settings(lang) { lang = it }
                    }
                }
                NavigationBar(containerColor = Panel) {
                    val icons = listOf(Icons.Default.Home, Icons.Default.List, Icons.Default.AddCircle, Icons.Default.BarChart, Icons.Default.Settings)
                    val labels = listOf("home", "tx", "add", "analytics", "settings")
                    icons.forEachIndexed { i, icon -> NavigationBarItem(page == i, { page = i }, { Icon(icon, null) }, label = { Text(tr(lang, labels[i]), fontSize = 10.sp) }) }
                }
            }
        }
    }
}

@Composable fun Header(lang: String, setLang: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().padding(18.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
        Column { Text("FINORA", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black); Text("Personal Finance", color = TextMuted, fontSize = 11.sp) }
        Box { TextButton({ open = true }) { Text(if (lang == "العربية") "ع" else lang.take(2).uppercase(), color = Red, fontWeight = FontWeight.Bold) }; DropdownMenu(open, { open = false }) { listOf("English", "Français", "العربية").forEach { DropdownMenuItem({ Text(it) }, { setLang(it); open = false }) } } }
    }
}

@Composable fun Dashboard(txs: List<TransactionEntity>, lang: String) {
    val income = txs.filter { it.type == "income" }.sumOf { it.amount }
    val expense = txs.filter { it.type == "expense" }.sumOf { it.amount }
    LazyColumn(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Card(Modifier.fillMaxWidth(), RoundedCornerShape(26.dp), colors = CardDefaults.cardColors(Panel)) { Column(Modifier.padding(23.dp)) { Text(tr(lang, "balance"), color = TextMuted); Text(money(income - expense), color = Color.White, fontSize = 31.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(18.dp)); Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) { Stat(tr(lang, "income"), money(income), Green); Stat(tr(lang, "expense"), money(expense), Red) } } } }
        item { Text(tr(lang, "recent"), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        if (txs.isEmpty()) item { Empty(tr(lang, "empty")) } else items(txs.take(8), key = { it.id }) { TransactionRow(it, lang) }
    }
}

@Composable fun Stat(label: String, value: String, color: Color) { Column { Text(label, color = TextMuted, fontSize = 12.sp); Text(value, color = color, fontWeight = FontWeight.Bold, fontSize = 16.sp) } }
@Composable fun Empty(text: String) { Box(Modifier.fillMaxWidth().padding(28.dp), Alignment.Center) { Text(text, color = TextMuted) } }

@Composable fun TransactionRow(t: TransactionEntity, lang: String) {
    Card(Modifier.fillMaxWidth(), RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(Panel)) {
        Row(Modifier.padding(15.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text(categoryLabel(lang, t.category), color = Color.White, fontWeight = FontWeight.SemiBold); Text(t.note.ifBlank { t.account }, color = TextMuted, fontSize = 12.sp) }
            Text((if (t.type == "income") "+" else "-") + money(t.amount), color = if (t.type == "income") Green else Red, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable fun Transactions(txs: List<TransactionEntity>, lang: String, vm: FinanceVm) {
    var query by remember { mutableStateOf("") }
    val filtered = txs.filter { query.isBlank() || it.note.contains(query, true) || it.category.contains(query, true) }
    Column(Modifier.padding(16.dp)) {
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), label = { Text("Search") }, singleLine = true, leadingIcon = { Icon(Icons.Default.Search, null) })
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) { items(filtered, key = { it.id }) { t -> Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(8.dp), Alignment.CenterVertically) { TransactionRow(t, lang); IconButton({ vm.delete(t) }) { Icon(Icons.Default.Delete, null, tint = Red) } } } }
    }
}

@Composable fun AddTransaction(lang: String, vm: FinanceVm) {
    var amount by remember { mutableStateOf("") }; var type by remember { mutableStateOf("expense") }; var cat by remember { mutableStateOf("food") }; var note by remember { mutableStateOf("") }; var account by remember { mutableStateOf("cash") }
    LazyColumn(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        item { Text(tr(lang, "add"), color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold) }
        item { OutlinedTextField(amount, { amount = it }, Modifier.fillMaxWidth(), label = { Text(tr(lang, "amount")) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true) }
        item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { FilterChip(type == "expense", { type = "expense" }, { Text(tr(lang, "expense")) }); FilterChip(type == "income", { type = "income" }, { Text(tr(lang, "income")) }) } }
        item { Text(tr(lang, "category"), color = TextMuted) }
        item { FlowRow(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) { categories.forEach { FilterChip(cat == it, { cat = it }, { Text(categoryLabel(lang, it)) }) } } }
        item { Text(tr(lang, "account"), color = TextMuted) }
        item { Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) { accounts.forEach { FilterChip(account == it, { account = it }, { Text(categoryLabel(lang, it)) }) } } }
        item { OutlinedTextField(note, { note = it }, Modifier.fillMaxWidth(), label = { Text(tr(lang, "note")) }) }
        item { Button({ amount.toDoubleOrNull()?.takeIf { it > 0 }?.let { vm.add(it, type, cat, note, account) } }, Modifier.fillMaxWidth(), RoundedCornerShape(16.dp)) { Text(tr(lang, "save")) } }
    }
}

@Composable fun Analytics(txs: List<TransactionEntity>, budgets: List<BudgetEntity>, lang: String, vm: FinanceVm) {
    val expenseByCat = txs.filter { it.type == "expense" }.groupBy { it.category }.mapValues { it.value.sumOf { x -> x.amount } }
    val max = expenseByCat.values.maxOrNull()?.coerceAtLeast(1.0) ?: 1.0
    LazyColumn(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text(tr(lang, "analytics"), color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold) }
        item { Text(tr(lang, "monthly"), color = TextMuted) }
        expenseByCat.entries.sortedByDescending { it.value }.forEach { (cat, value) -> item { Column { Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) { Text(categoryLabel(lang, cat), color = Color.White); Text(money(value), color = Red, fontWeight = FontWeight.Bold) }; LinearProgressIndicator({ (value / max).toFloat().coerceIn(0f, 1f) }, Modifier.fillMaxWidth().padding(top = 7.dp), color = Red, trackColor = Panel) } } }
        item { Text(tr(lang, "budget"), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        item { BudgetEditor(lang, vm) }
        items(budgets) { b -> val spent = expenseByCat[b.category] ?: 0.0; val p = (spent / b.amount).toFloat().coerceIn(0f, 1f); Card(colors = CardDefaults.cardColors(Panel), shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(15.dp)) { Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) { Text(categoryLabel(lang, b.category), color = Color.White); Text("${money(spent)} / ${money(b.amount)}", color = TextMuted, fontSize = 12.sp) }; LinearProgressIndicator({ p }, Modifier.fillMaxWidth().padding(top = 8.dp), color = if (p >= 1f) Red else Green, trackColor = Bg) } } }
    }
}

@Composable fun BudgetEditor(lang: String, vm: FinanceVm) {
    var cat by remember { mutableStateOf("food") }; var amount by remember { mutableStateOf("") }
    Card(colors = CardDefaults.cardColors(Panel), shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) { Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) { categories.take(4).forEach { FilterChip(cat == it, { cat = it }, { Text(categoryLabel(lang, it)) }) } }; OutlinedTextField(amount, { amount = it }, Modifier.fillMaxWidth(), label = { Text(tr(lang, "amount")) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true); Button({ amount.toDoubleOrNull()?.takeIf { it > 0 }?.let { vm.saveBudget(cat, it) } }, Modifier.fillMaxWidth()) { Text(tr(lang, "save")) } } }
}

@Composable fun Settings(lang: String, setLang: (String) -> Unit) {
    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) { Text(tr(lang, "settings"), color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold); Text(tr(lang, "language"), color = TextMuted); listOf("English", "Français", "العربية").forEach { display -> Button({ setLang(display) }, Modifier.fillMaxWidth(), RoundedCornerShape(14.dp)) { Text(display) } } }
}

private fun Modifier.noop() = this
