# Finora Finance

Professional offline-first Android personal finance manager.

## Features
- English / Français / العربية (RTL-ready UI)
- Dashboard with balance, income and expenses
- Transactions with search, categories and accounts
- Budgets by category
- Spending analytics
- Local Room database; no account or internet required for core features
- DZD currency by default
- Dark modern Material 3 UI

## Build
Open this folder in Android Studio (Hedgehog or newer recommended), let Gradle sync, then:
**Build > Generate App Bundle(s) / APK(s) > Generate APK(s)**.

Minimum Android: 8.0 (API 26). Target SDK 35.

## Build on GitHub (recommended for low-end PCs)

This project includes GitHub Actions workflows, so the Android build can run on GitHub's cloud runners instead of your computer.

### From a phone
1. Create a GitHub repository and upload the **contents of this project folder**.
2. Open the repository in GitHub.
3. Open **Actions**.
4. Select **Build Finora APK**.
5. Press **Run workflow**.
6. Wait for the green checkmark.
7. Open the completed workflow run and download the **Finora-debug-apk** artifact.
8. Extract the ZIP and install the APK on your Android phone.

The normal debug workflow also runs automatically when you push to `main` or `master`.

### Important
The release workflow currently creates an **unsigned release APK**. For a distributable production APK, configure Android signing secrets and add a signing step before publishing.
